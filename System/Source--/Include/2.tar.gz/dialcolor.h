#ifndef DIALCOLOR_H
#define DIALCOLOR_H

#include <QWidget>
#include <QPaintEvent>

class Q_DECL_EXPORT DialColor : public QWidget
{
    Q_OBJECT
  public:
    QColor color;
    explicit DialColor( QWidget *parent = nullptr);
    void mousePressEvent(QMouseEvent *event);
    void paintEvent(QPaintEvent *event);
  signals:
};

#endif // DIALCOLOR_H
