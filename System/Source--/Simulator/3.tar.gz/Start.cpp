#include "Start.h"
#include "BaseModel.h"
#include "CommProc.h"
#include <QLibrary>
#include "Err.h"
#include "Prop.h"
#include "DataTypes.h"
#include "SysDataTypes.h"
#include <unistd.h>
#include <QSemaphore>

IBaseModel * pCtrlConn;
extern  QSemaphore Sem_Model;

Start::Start(QObject* parent )
  {

  }

Start::~Start()
  {
  }

Hydro::Hydro(QObject* parent )
  {

  }

Hydro::~Hydro()
  {
  }


void Hydro::start()
  {
  Go();
  }

void Start::start()
  {
  emit started();
  if ( !Prepare())
   {
  //  emit stopped();
    return;
   }
//
  emit loaded();
  // while ( !Stop )
  //   {
  //   sleep(1);
  //   KKK();
  //   }
  InitWork();
  Pause = false;
  Sem_Model.release();
  Go();
  KKK();
  }



void Start::stop ()
  {
  emit stopped();
  }

 int Q_DECL_IMPORT RestoreParamsFromFile(LPCTSTR szFilePath);
 int Q_DECL_IMPORT RestoreStateFromFile ( LPCTSTR File_Path );

 bool Start::Load()
  {
   // QString Path = EXE_PATH;
   // Path += "/libUniHydro.so";
   // QLibrary Lib(Path);
   // bool Res = Lib.load();
   // if ( !Res )
   // {
   //  QString Err = Lib.errorString();
   //  return false;
   // }
   // tCreateObject pCreateObj = (tCreateObject)Lib.resolve("CreateObject");
   // if ( pCreateObj == NULL )
   //   return false;
   // IBaseModel * pMainHydro = (*pCreateObj)( "Гидравлика", "" );
   // int ResStart = pMainHydro->Init( 0 );
   return true;
  }

IBaseModel * LoadStdLib ( const char * Dll, const char * Name )
  {
  IBaseModel * pLib = Load_Object( Dll, Name );
  if (!pLib)
    {
      SysMSG( "Ошибка загрузки библиотеки '%s'", Name );
//      Critical( "Ошибка загрузки библиотеки '%s'", Name );
      return NULL;
    }
//  pLib->Init( 0 );
  return pLib;
  }

bool Start::Prepare()
  {
  if ( !PROPS.ReadProp())
    {
#ifdef LINUX
//    CLogFile::Log ("Start 9: !PROPS.ReadProp");
#endif // LINUX
    SysMSG ( "Ошибка чтения настроек" );
    }
  char Project_Name[64];
  char Project_Root[64];
  PROPS.Get( "Проект", Project_Name );
  //pSys = new CSystem;//(CSystem*)CreateStruct( 1, "Система" );;
  //pSys->Init();
  //PROPS.Get( "Корневая папка", Project_Root );
  //PROPS.Get( "Температура окружающей среды", T_air );
  PROPS.Get( "Минимальная температура", T_min );
  PROPS.Get( "Максимальная температура", T_max );
  //extern double gMaxNew_dt;
  //PROPS.Get( "Начальный шаг по времени", gMaxNew_dt );
  ////
  GiveCommData( "Модель", CExternalCondition::TypeID, (void**)&pExt );
  GiveCommData( "Модель", CSystem::TypeID, (void**)&pSys );
  pSys->WaterIAPWS = false;
  PROPS.Get( "Вода по IAPWS", pSys->WaterIAPWS );
  IBaseModel * pChem = LoadStdLib ( "Chem", "Химия" );
  pChem->Init(0);
  UseAlt_CompNames = false;
  PROPS.Get ( "Альтернативные", UseAlt_CompNames );
  IBaseModel * pData = LoadStdLib( "Data", "Данные" );
  pData->Init(0);
  IBaseModel * pTrend = LoadStdLib( "Trends", "Тренды" );
  pCtrlConn = LoadStdLib("CtrlConn", "Управление");
  IBaseModel * pACS = LoadStdLib( "ACS", "ACS");
  IBaseModel * pCtrlReg = LoadStdLib( "CtrlReg", "Регуляторы");
  //////////////////////////////////////////////
  ///
  SysMSG ( "#Загрузка проекта" );
  pMainHydro = Load_Object( "UniHydro", "Гидравлика" );
  if ( pMainHydro == nullptr )
  {
    SysMSG( "Ошибка загрузки UniHydro" );
    return __LINE__;
  }
  int Res = pMainHydro->Init( 0 );
  if ( Res )
    {
    SysMSG( "Ошибка загрузки моделей" );
//    Critical( "Ошибка загрузки моделей" );
    return __LINE__;
  }
  SysMSG ( "#Инициализация объектов" );
  // bool bOG = false;
  // PROPS.Get(PROPKEY_GAS_CONTAMIN, bOG );
  // if( bOG )
  //  {
  //   Load_Object("OGCtrl", "OG", "OG");
  //   }

  // pExt->T_Air = 15.0;	// Температура окружающего воздуха//-параметр(2)
  // pExt->PressAirKip = 7.0;//Давление воздуха КИП
  // pExt->WorkUPS = true;
  // pExt->WorkDCS = true;
  // pExt->IsElectro_380 = true;
  // pExt->IsElectro_6000 = true;
  // pExt->IsPumpSbros = true;
  // pExt->IsBlk = false;
  // pExt->CtrlMinMax = true;
  // pExt->IsEmptyVol = true;
  // //
  pSys->m_nStep = 0;
  // pSys->StartStatus = CSystem::STATUS_INIT;
  // bool Blk = false;
  // PROPS.Get( PROPKEY_BLOCKAGES, Blk );
  // pExt->IsBlk = Blk;
  // pSys->IsBlk = Blk;
  ////////////////////////////////////////
  //pTrend->Init(0);
//
  SysMSG ("#Инициализация рабочих моделей");
  IBaseModel * pObj = IBaseModel::pFirst;
  while ( pObj )
    {
    pObj->Init( 3 );
    pObj = pObj->pNext;
    }
  IBaseModel::SetObjectsList();
  SysMSG ("#Чтение параметров");
  char Path[1024];
  sprintf ( Path, "%sDATA/STATES/N.parm", PROJECT_ROOT );
  int ResParm = RestoreParamsFromFile( Path );
//
  bool Err = false;
  SysMSG( "#Начальный шаг моделей объектов" );
  for ( int n = 0; n < IBaseModel::kObjects; n++ )
    {
    IBaseModel * pModel = IBaseModel::AllObjects[n];
    if ( pModel && pModel->Step0( ))
      {
      SysMSG( "Ошибка на начальном шаге объекта '%s'('%s')",
             (char*)pModel->ObjName, (char*)pModel->Model );
//      Critical( "Ошибка на начальном шаге объекта '%s'('%s')",
//               (char*)pModel->ObjName, (char*)pModel->Model );
      Err = true;
    }
  }
  if(Err)
    return __LINE__;
  SysMSG ("#Чтение состояния");
  char PathState[1024];
  sprintf ( PathState, "%sDATA/STATES/N.dat", PROJECT_ROOT );
  int ResState = RestoreStateFromFile( PathState );
  SysMSG( "#Первый шаг моделей объектов" );
  for ( int n = 0; n < IBaseModel::kObjects; n++ )
    {
    IBaseModel * pModel = IBaseModel::AllObjects[n];
    if ( pModel && pModel->Step1( ))
    {
      SysMSG( "Ошибка на первом шагe объекта '%s'('%s')",
             (char*)pModel->ObjName, (char*)pModel->Model );
//      Critical( "Ошибка на первом шагe объекта '%s'('%s')",
//               (char*)pModel->ObjName, (char*)pModel->Model );
      Err = true;
    }
  }
  if(Err) return false;
  if( SysErrors > 0 )
    {
     SysMSG(  "Загрузка остановлена из-за ошибок" );
    return false;
    }
  SysMSG( "#Модель работает" );
  KKK();
  return true;
  }
