#ifndef PARAMSTREE_H
#define PARAMSTREE_H
#include <QTreeView>
#include "Param.h"
#include <QStandardItemModel>

struct ParamsTree : public QTreeView
{
    CParams * pParams;
    int kParams;
    QStandardItemModel * pRoot;
    ParamsTree(QWidget * Parent ) : QTreeView ( Parent )
    {

    }
    void Init ( int kParams, CParams * pParams, char * ObjName );
};

#endif // PARAMSTREE_H
