#ifndef START_H
#define START_H
#include <QObject>
#include "CommProc.h"

class Start : public QObject
{
 Q_OBJECT
  public:
  ProcessData PD;

    explicit Start(QObject* parent = nullptr);
    virtual ~Start();
    bool Load();
    bool Prepare();
    void InitWork();
    void Go();
  public slots:

    virtual void start();
    virtual void stop ();

  signals:
    void started();
    void stopped();
    void loaded();
    void ShowSteps ( int kSteps );
    void ShowAccel ( double Accel );
    void ShowData ( double ProcUser, int Mem );

};

class Hydro : public QObject
{
    Q_OBJECT
  public:
    ProcessData PD;

    explicit Hydro(QObject* parent = nullptr);
    virtual ~Hydro();
    void Go();
  public slots:
    virtual void start();
  signals:
    void ShowData ( double ProcUser, int Mem );
};

#endif // START_H
